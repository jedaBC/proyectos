/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alvarezquiz2;

/**
 *
 * @author barbaraalvarez
 */
public class Pilas<T> {
    
    private class Nodo{
        T info;
        Nodo next;
        
        public Nodo(T info){
            this.info = info;
            next = null;
        }
    }
    
    public Nodo cima;
    public int size;
    
    public Pilas(){
        size = 0;
        cima = null;
    }
    
    //Metodo para saber si la pila esta vacia
    public boolean isEmpty(){
        return size == 0;
    }
    
    //Metodo para agregar un nuevo objeto a la pila
    public void apilar(T info){
        Nodo nuevoNodo = new Nodo(info);
        
        if(size == 0){
            cima = nuevoNodo;
            
        } else {
            Nodo temp = cima;
            cima = nuevoNodo;
            nuevoNodo.next = temp;
        }
        size++;
    }
    
    //Metodo para eliminar el elemento que se encuentra en
    //la cima
    public void desapilar(){
        if (cima != null) {
            cima = cima.next;
            size--;
        }
    }
    
    //Metodo para obtener el valor de la cima
    public T getCima(){
        if (cima != null) {
            return cima.info;
        } 
        return null;
        
    }
    
    
    
    
   
    
    
    
    
    
    
    
    
    
}
