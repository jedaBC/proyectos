/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alvarezquiz2;

/**
 *
 * @author barbaraalvarez
 */
public class Nodo2 <T>{
    private T data;
    private Node next;

    public Nodo2(T ddata) {
            this.data = ddata;
            this.next = null;
    }

    public T get_info(){
        return this.data;
    }
    
    public void Set_info(T data){
        this.data = data;
    }
    
    public Node Left_child(){
        return this.next;
    }
    
    public void Set_Left_child(Node n){
        this.next = n;
    }
    
    
}
