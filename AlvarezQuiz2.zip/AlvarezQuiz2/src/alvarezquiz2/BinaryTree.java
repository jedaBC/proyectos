package alvarezquiz2;



public class BinaryTree {
    Node root;

    public BinaryTree() {
            this.root = null;
    }
    public boolean its_empty(Node n){
        return n==null;
    }
    public void insertLeft( String parent, String leftvalue) {
            Node n = find(root, parent);
            Node leftchild = new Node(leftvalue);
            n.Set_Left_child(leftchild);
    }

    public void insertRight( String parent,String rightvalue) {
            Node n = find(root, parent);
            Node rightchild = new Node(rightvalue);
            n.Set_Right_child(rightchild);
    }

    public void insertRoot( String data) {
        root = new Node(data);
    }

    public Node getRoot() {
            return root;
    }

    public Node find(Node n,String key) {
            Node result = null;
            if (n == null)
                    return null;
            if (n.get_info() == key)
                    return n;
            if (n.Left_child() != null)
                    result = find(n.Left_child(), key);
            if (result == null)
                    result = find(n.Right_child(), key);
            return result;
    }
    
    public void agregarSonLeft(BinaryTree sonLeft){
        this.root.Set_Left_child(sonLeft.root);
    }
    
    public void agregarSonRight(BinaryTree sonRight){
        this.root.Set_Right_child(sonRight.root);
    }



    public void printTree(Node n) {
        if (n == null)
            return;
        printTree(n.Left_child());
        printTree(n.Right_child());
    }

    public String Preorden(Node n){
        String recorrido = "";
        if (n == null){
            return "";

        }
        recorrido+=n.get_info();
        recorrido += Preorden(n.Left_child());
        recorrido += Preorden(n.Right_child());
        
        return recorrido;
    }

    public void InOrder(Node n){
        if (n == null)
            return;
        InOrder(n.Left_child());
        n.displayNode(n);
        InOrder(n.Right_child());
    }

    public String Postorden(Node n){
        String recorrido = "";

        if (n == null) {
            return "";
        }

        recorrido += Postorden(n.Left_child());
        recorrido += Postorden(n.Right_child());
        recorrido+=n.get_info();
        return recorrido;

    }
    
    public int getheight(Node root) {
        if (root == null)
            return 0;
        return Math.max(getheight(root.Left_child()), getheight(root.Right_child())) + 1;
    }
    
/**
* 
* @param clave
* @param ABB
* @return boolean
* Precondicion: solo inserta valores no existentes en el arbol. 
* Insercion iterativa.
*/	
//    public boolean Insert_iterate( String clave, Node ABB){
//        Node donde, padre;
//        boolean encontrado= false;
//        padre=null;
//        donde= ABB;
//        while (!its_empty(donde) && !encontrado){
//            padre=donde;
//            if (clave == donde.get_info()){
//                    encontrado=true;
//            }else{
//                if(clave < donde.get_info() ) {
//                    donde=donde.Left_child();
//                }else{
//                    donde=donde.Right_child();
//                }
//            }
//        }
//        // insert.
//        if(!encontrado){
//            donde=new Node(clave);
//            if(its_empty(padre)){
//                ABB=donde; // first node.
//            }else{
//                if(clave < padre.get_info()) {
//                    padre.Set_Left_child(donde);
//                }else{
//                    padre.Set_Right_child(donde);
//                }
//            }
//            return true;
//        }else{
//            return false;
//        }
//    }

/**
* Insercion recursiva.
* Solo inserta valores no repetidos.
* @param clave
* @param ABB
* @return 
*/
//    public boolean Insert_recur( String clave, Node ABB){
//        if(its_empty(ABB)){
//            ABB=new Node(clave);
//            return true;
//        } else{
//            if(clave==ABB.get_info()){
//                return false;
//            }else{
//                if(clave<ABB.get_info()){
//                    if (this.its_empty(ABB.Left_child())){
//                        ABB.Set_Left_child(new Node(clave));
//                        return true;
//                    }else{
//                        return Insert_recur(clave,ABB.Left_child());
//                    }
//                }else{
//                    if (this.its_empty(ABB.Right_child())){
//                        ABB.Set_Right_child(new Node(clave));
//                        return true;
//                    }else{
//                        return Insert_recur(clave,ABB.Right_child());
//                    }
//                }
//
//            }
//        }
//    }
        
        
        
    public Node Max(Node n) {
        if (n.Right_child() == null) {
            return n;
        } else {
            return Max(n.Right_child());
    }
} 

}